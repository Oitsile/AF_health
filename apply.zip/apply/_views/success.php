<div class="container">
    <div class="wrapper margin-fix">
        <h3>Your application was submitted successfully!</h3>
        <p>Thank you for choosing Affinity Health. We can't wait to add you to the family!</p>
        <p>One of our friendly agents will be in contact with you shortly to get you sorted.</p>
        <a class="goback" href="https://www.affinityhealth.co.za/">Go back to the website</a>
    </div>
</div>
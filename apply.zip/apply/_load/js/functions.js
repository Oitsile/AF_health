$(document).ready(function () {"use strict";
		$('#idtooltip').hide();
		$("#junior-add").hide();
		$("#sidebar-d2d").hide();
		$("#sidebar-j-d2d").hide();
		$("#sidebar-hos").hide();
		$("#sidebar-com").hide();
		$("#add_spouse").hide();
		$("#addchild").hide();
		//$('#dc01').hide();
		
	
	/*=================================*/
							   
							   
	
$("#cover-selector").change(function(){
        $(this).find("option:selected").each(function(){
			var value1 = $(this).attr("value");
            if(value1==1 || value1==4){
                $("#add_spouse").show('fast');
				$("#sidebar-d2d").show('fast');
				$("#sidebar-hos").hide('fast');
				$("#sidebar-com").hide('fast');
				$("#addchild").show('fast');
				$("#sidebar-j-d2d").hide('fast');
				$('select[name*="addchild"] option[value="0"]').show();
				$('select[name*="addchild"] option[value="200"]').show();
				$('select[name*="addchild"] option[value="201"]').hide();
				$('select[name*="addchild"] option[value="200"]').attr("selected",true);
				$('select[name*="addchild"] option[value="201"]').attr("selected",false);

            }
			else if(value1==2 || value1==105 || value1==6){
                $("#add_spouse").show('fast');
				$("#sidebar-d2d").hide('fast');
				$("#sidebar-hos").show('fast');
				$("#sidebar-com").hide('fast');
				$("#addchild").show('fast');
				$("#sidebar-j-d2d").hide('fast');
				$('select[name*="addchild"] option[value="0"]').show();
				$('select[name*="addchild"] option[value="200"]').show();
				$('select[name*="addchild"] option[value="201"]').hide();
				$('select[name*="addchild"] option[value="200"]').attr("selected",true);
				$('select[name*="addchild"] option[value="201"]').attr("selected",false);
            }
			else if(value1==3 || value1==106 || value1==7){
                $("#add_spouse").show('fast');
				$("#sidebar-d2d").hide('fast');
				$("#sidebar-hos").hide('fast');
				$("#sidebar-com").show('fast');
				$("#addchild").show('fast');
				$("#sidebar-j-d2d").hide('fast');
				$('select[name*="addchild"] option[value="0"]').show();
				$('select[name*="addchild"] option[value="200"]').show();
				$('select[name*="addchild"] option[value="201"]').hide();
				$('select[name*="addchild"] option[value="200"]').attr("selected",true);
				$('select[name*="addchild"] option[value="201"]').attr("selected",false);
            }
			else if(value1==5){
                $("#add_spouse").hide('fast');
				$("#sidebar-d2d").hide('fast');
				$("#sidebar-hos").hide('fast');
				$("#sidebar-com").hide('fast');
				$("#sidebar-j-d2d").show('fast');
				$("#addchild").show('fast');
				$('select[name*="addchild"] option[value="0"]').hide();
				$('select[name*="addchild"] option[value="200"]').hide();
				$('select[name*="addchild"] option[value="201"]').show();
				$('select[name*="addchild"] option[value="200"]').attr("selected",false);
				$('select[name*="addchild"] option[value="201"]').attr("selected",true);

            }
            else{
				$("#add_spouse").hide();
				$('select[name*="addchild"] option[value="0"]').hide();
				$('select[name*="addchild"] option[value="200"]').hide();
				$('select[name*="addchild"] option[value="201"]').hide();
				$("#junior-add").hide('fast');
            }
        });
}).change();
							   
$("#inso").change(function(){
        $(this).find("option:selected").each(function(){
            if($(this).attr("value")==='Salary'){
				$('select[name*="payper"] option[value="Not Employed"]').hide();
            }
            else{
				$('select[name*="payper"] option[value="Not Employed"]').show();
            }
        });
}).change();
							   
/*============== ID Number Tooltip ===================*/
							   
$('#idinfo').click(function(e){
   if($('#idtooltip').css("display") === 'none'){
      $('#idtooltip').slideDown("fast");
	  $('.overlay').fadeIn("fast");
   }

   else{
      $('#idtooltip').slideUp("fast");
	   $('.overlay').fadeOut("fast");
   }
	e.stopPropagation();
});

$(document).on( "click", function( e) {  
     e.stopPropagation();
	$('#idtooltip').slideUp("fast");
	$('.overlay').fadeOut("fast");
});

	
/*=================================*/

	});
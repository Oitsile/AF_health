/*
| ================================================================================
| ../js/cd.steps.js
| This file contains the various functions that handle
| each step as it is submitted
| ~ C.D.
| ================================================================================
*/

function test2() {
    alert('yo');
}

